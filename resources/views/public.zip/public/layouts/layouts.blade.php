@include('public/includes.header')
@include('public/includes.nav')
@yield('content')
@include('public/includes.footer')
@yield('script')

